sleep 1
if [ -d /data/adb/modules ]; then
 Module=/data/adb/modules
elif [ -d /sbin/.core/img ]; then
 Module=/sbin/.core/img
elif [ -d /sbin/.magisk/img ]; then
 Module=/sbin/.magisk/img
fi

ui_print ""
ui_print "**************************************"
ui_print ""
ui_print "███╗░░░███╗███████╗███╗░░██╗░██████╗░████████╗"
ui_print "████╗░████║██╔════╝████╗░██║██╔════╝░╚══██╔══╝"
ui_print "██╔████╔██║█████╗░░██╔██╗██║██║░░██╗░░░░██║░░░"
ui_print "██║╚██╔╝██║██╔══╝░░██║╚████║██║░░╚██╗░░░██║░░░"
ui_print "██║░╚═╝░██║███████╗██║░╚███║╚██████╔╝░░░██║░░░"
ui_print "╚═╝░░░░░╚═╝╚══════╝╚═╝░░╚══╝░╚═════╝░░░░╚═╝░░░"
ui_print ""
ui_print "**************************************"
ui_print ""
ui_print "- MengT "
ui_print "- By: AkiraSuper "
ui_print "- Status: vFINAL "
ui_print "- Device SOC: $(getprop ro.product.board) "
ui_print ""
ui_print "**************************************"
ui_print ""

if [[ -d $Module/*thermal* ]]
then
echo "- MengT Detected Thermal Module Aborting For Security Purposes "
exit 0
elif [[ -d $Module/*Thermal* ]]
then
echo "- MengT Detected Thermal Module Aborting For Security Purposes "
exit 0
elif [[ -d $Module/Aurox* ]]
then
echo "- MengT Detected Aurox-T Module Aborting For Security Purposes "
exit 0
elif [[ -d $Module/tengine ]]
then
echo "- MengT Detected T-Engine Module Aborting For Security Purposes "
exit 0
fi

B=$(getprop ro.product.board 2>/dev/null)
P=$(getprop ro.board.platform 2>/dev/null)
SD=sdm660

case "$SD" in
 "$B"|"$P")
  SDM=1
 ;;
esac

sleep 1

if [ "$SDM" == "1" ]; then
echo " $B Detected Installation Approved!"

else
echo " $B Only Installation Not Approved!"
exit 0
fi

if [ -e /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors ]; then
 CPU=/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors
elif [ -e /sys/devices/system/cpu/cpu1/cpufreq/scaling_available_governors ]; then
 CPU=/sys/devices/system/cpu/cpu1/cpufreq/scaling_available_governors
elif [ -e /sys/devices/system/cpu/cpu2/cpufreq/scaling_available_governors ]; then
 CPU=/sys/devices/system/cpu/cpu2/cpufreq/scaling_available_governors
elif [ -e /sys/devices/system/cpu/cpu3/cpufreq/scaling_available_governors ]; then
 CPU=/sys/devices/system/cpu/cpu3/cpufreq/scaling_available_governors
elif [ -e /sys/devices/system/cpu/cpu4/cpufreq/scaling_available_governors ]; then
 CPU=/sys/devices/system/cpu/cpu4/cpufreq/scaling_available_governors
elif [ -e /sys/devices/system/cpu/cpu5/cpufreq/scaling_available_governors ]; then
 CPU=/sys/devices/system/cpu/cpu5/cpufreq/scaling_available_governors
elif [ -e /sys/devices/system/cpu/cpu6/cpufreq/scaling_available_governors ]; then
 CPU=/sys/devices/system/cpu/cpu6/cpufreq/scaling_available_governors
elif [ -e /sys/devices/system/cpu/cpu7/cpufreq/scaling_available_governors ]; then
 CPU=/sys/devices/system/cpu/cpu7/cpufreq/scaling_available_governors
elif [ -e /sys/devices/system/cpu/cpu8/cpufreq/scaling_available_governors ]; then
 CPU=/sys/devices/system/cpu/cpu8/cpufreq/scaling_available_governors
elif [ -e /sys/devices/system/cpu/cpu9/cpufreq/scaling_available_governors ]; then
 CPU=/sys/devices/system/cpu/cpu9/cpufreq/scaling_available_governors
fi

SP=$(cat $CPU)
case "$SP" in
 *util*) 
  eas=1
 ;;
 *sched*) 
  eas=1
 ;;
 *elect*) 
  eas=1
 ;;
 esac

sleep 1

if [ "$eas" == "1" ]; then
PH="And Pixel PowerHAL"
KT="EAS"
rm -rf $MODPATH/LICENSE
rm -rf $MODPATH/README.md
sed -i '/sys.use_fifo_ui=/s/.*/sys.use_fifo_ui=1/' $MODPATH/system.prop;
sed -i '/persist.device_config.runtime_native.usap_pool_enabled=/s/.*/persist.device_config.runtime_native.usap_pool_enabled=true/' $MODPATH/system.prop;
sed -i '/ro.surface_flinger.max_frame_buffer_acquired_buffers=/s/.*/ro.surface_flinger.max_frame_buffer_acquired_buffers=3/' $MODPATH/system.prop;

else
KT="HMP"
rm -rf $MODPATH/LICENSE
rm -rf $MODPATH/README.md
rm -rf $MODPATH/service.sh
rm -rf $MODPATH/system.prop
rm -rf $MODPATH/system/lib
rm -rf $MODPATH/system/lib64
rm -rf $MODPATH/system/vendor/bin
rm -rf $MODPATH/system/vendor/etc/init
rm -rf $MODPATH/system/vendor/etc/perf
rm -rf $MODPATH/system/vendor/etc/msm_irqbalance.conf
rm -rf $MODPATH/system/vendor/etc/powerhint.json
rm -rf $MODPATH/system/vendor/lib64
fi

TEXT1="MengT Thermal Engine $PH For $(getprop ro.product.board). "
TEXT2="$KT Kernel: $(uname -r)"
sed -i "/description=/c description=${TEXT1}${TEXT2}" $MODPATH/module.prop;
sleep 1