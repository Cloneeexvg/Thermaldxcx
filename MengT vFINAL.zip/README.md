##### MengT Thermals | Magisk Module

##### Contact: [Akira](https://t.me/AkiraProjects)

### Introduction: Thermal configuration for Snapdragon™ 636 and 660 Mobile Platforms!

### - Credits -

- MengT Kernel Developer - [sYYLG](https://t.me/sYYLG)
- Agni Kernel Developer - [psndna88](https://t.me/psndna881)
- Pixel PowerHAL Developer - [Ratoriku](Ratoriku@github.com)
- Pixel PowerHAL Boot tools Developer - [Yuhan Zhang](yuhan@rsyhan.me)
- Perf Boost Config Developer - [Uvera](https://t.me/uvera)
- NFS Lead Developer - [K1ks](https://t.me/K1ks1)
- FKM Spectrum Injector Developer - [WeAreRavenS](https://t.me/WeAreRavenS)
- MMT-Extended - [Zackptg5](https://forum.xda-developers.com/apps/magisk/magisk-module-template-extended-mmt-ex-t4029819)

##### Disclaimer: Naturally, you take all the responsibility for what happens to your device when you start messing around with things. I (Akira) will not be responsible for ANY damage caused to anyone's devices due to the use of this module.

##### Yes, works on all ROMs and on all firmwares.

##### ✓ INSTALLATION: Just flash via Magisk and reboot

#### - ChangeLog - 

### Version: vFINAL

- Update MMT-e V1.6 ( Magisk 20+ )
- Add Detection Kernel Type
- Hmp / Eas Support
- Added Pixel PowerHAL
- Improve Security for Conflict Before Install
- Add Security for Check Device Before Install