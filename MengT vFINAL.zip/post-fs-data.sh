$MODDIR/system/bin/mengt
mods=/data/adb/modules
# Module Disabler
# by: @WeAreRavens
if [ -e $MODDIR ]; then
    for p in $mods/*powerhal*; do
        touch $p/disable;
    done;
    for p in $mods/*PowerHAL*; do
        touch $p/disable;
    done;
    if [ -e $mods/jasoneaspower ]; then
        touch $mods/jasoneaspower/disable
    fi
fi
if [ -e $MODDIR/system/vendor/bin/thermal-engine ]; then
    for t in $mods/*thermal*; do
        touch $t/disable;
    done;
    for t in $mods/*Thermal*; do
        touch $t/disable;
    done;
fi
if [ -e $mods/AuroxT ]; then
    touch $mods/AuroxT/disable
done;
if [ -e $mods/tengine ]; then
    touch $mods/tengine/disable
done;

